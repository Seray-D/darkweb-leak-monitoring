"""
database.py
SQLAlchemy engine, session ve Base tanımları.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

SQLALCHEMY_DATABASE_URL = "sqlite:///./leaks.db"

# SQLite için check_same_thread=False gerekli (FastAPI çoklu thread kullanabilir)
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency: her istek için bir DB session açar, sonra kapatır."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
