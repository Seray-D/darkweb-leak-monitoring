"""
main.py
FastAPI uygulaması: Dark Web Leaks Monitoring paneli - Aşama 1 (Backend & DB).

Çalıştırmak için:
    pip install fastapi uvicorn sqlalchemy httpx pydantic
    uvicorn main:app --reload

Endpoint'ler:
    GET /api/v1/leaks                -> tüm sızıntı kayıtlarını listeler
    GET /api/v1/scan?email=...       -> XposedOrNot'tan canlı sorgu yapar ve DB'ye işler
"""

from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import Base, engine, get_db
from models import BreachLog
from schemas import BreachLogOut
from seed import seed_if_empty
from xposed_service import check_email_breaches, build_breach_log_entries

app = FastAPI(
    title="Dark Web Leaks Monitoring API",
    description="Tehdit istihbaratı paneli için backend servisi",
    version="1.0.0",
)


@app.on_event("startup")
def on_startup() -> None:
    """Uygulama başlarken tabloları oluştur ve boşsa mock veri ekle."""
    Base.metadata.create_all(bind=engine)
    seed_if_empty()


@app.get("/api/v1/leaks", response_model=list[BreachLogOut])
def list_leaks(db: Session = Depends(get_db)):
    """Veritabanındaki tüm sızıntı kayıtlarını döner (frontend paneli için)."""
    logs = db.query(BreachLog).order_by(BreachLog.id.desc()).all()
    return logs


@app.get("/api/v1/scan", response_model=list[BreachLogOut])
async def scan_email(
    email: str = Query(..., description="Sorgulanacak e-posta adresi"),
    db: Session = Depends(get_db),
):
    """
    XposedOrNot servisinden canlı sorgu yapar, sonucu breach_logs tablosuna
    kaydeder ve eklenen (veya bulunamadıysa boş) kayıtları döner.
    """
    if "@" not in email:
        raise HTTPException(status_code=400, detail="Geçerli bir e-posta adresi giriniz.")

    scan_result = await check_email_breaches(email)

    if "error" in scan_result:
        raise HTTPException(status_code=502, detail=scan_result["error"])

    new_entries = build_breach_log_entries(email, scan_result)

    saved_rows = []
    for entry in new_entries:
        db_row = BreachLog(**entry)
        db.add(db_row)
        saved_rows.append(db_row)

    if saved_rows:
        db.commit()
        for row in saved_rows:
            db.refresh(row)

    return saved_rows
