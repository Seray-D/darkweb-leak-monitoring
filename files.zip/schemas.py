"""
schemas.py
Pydantic modelleri: API'nin giriş/çıkış veri şekillerini tanımlar.
"""

from pydantic import BaseModel


class BreachLogBase(BaseModel):
    asset: str
    email_leak: str
    leaked_password: str = "******"
    leak_type: str | None = None
    market: str | None = None
    last_seen: str | None = None
    certainty: str = "Unsure"
    status: str = "Active"
    priority: str = "Info"
    discovery_date: str | None = None


class BreachLogCreate(BreachLogBase):
    pass


class BreachLogOut(BreachLogBase):
    id: int

    class Config:
        from_attributes = True  # Pydantic v2: ORM objesinden okumaya izin verir
