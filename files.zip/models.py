"""
models.py
breach_logs tablosunun SQLAlchemy ORM modeli.
"""

from sqlalchemy import Column, Integer, String
from database import Base


class BreachLog(Base):
    __tablename__ = "breach_logs"

    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    asset = Column(String, nullable=False)                 # Örn: "izmir.bel.tr"
    email_leak = Column(String, nullable=False, index=True)  # Örn: "yagizer"
    leaked_password = Column(String, default="******")     # Varsayılan maskeli
    leak_type = Column(String, nullable=True)               # "Botnet", "Stealer Log"...
    market = Column(String, nullable=True)                  # "Combolist" vb.
    last_seen = Column(String, nullable=True)                # "2026-05-20"
    certainty = Column(String, default="Unsure")             # "Unsure" / "Confirmed"
    status = Column(String, default="Active")                # "Active" / "Resolved"
    priority = Column(String, default="Info")                # "Info"/"High"/"Critical"
    discovery_date = Column(String, nullable=True)            # "2026-07-12 23:29:06"
