"""
FastAPI ana uygulama.

/api/v1/scan tetiklendiğinde XposedOrNot, LeakIX ve AlienVault OTX
servislerini PARALEL olarak sorgular, sonuçları ortak NormalizedLeak
şemasına göre tek listede birleştirir ve veritabanına tek seferde yazar.

NOT: Bu dosya, sizin mevcut main.py'nizin YERİNE GEÇECEK şekilde tam olarak
yazılmıştır ama kendi xposed_service.py fonksiyon adınızla (aşağıda
`XPOSED_CHECK_FN` olarak işaretlenmiştir) uyumlu hale getirmeniz gerekir.
"""

import asyncio
import logging
from typing import List

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from database import Base, engine, get_db
from models import BreachLog
from schemas import NormalizedLeak
from services import leakix_service, otx_service
from services.xposed_adapter import normalize_xposed_results

# Kendi xposed_service.py dosyanızı import edin.
# Fonksiyon adı farklıysa (örn. `scan_email`, `search_xposed`) aşağıdaki
# `xposed_service.check_email(...)` çağrısını buna göre güncelleyin.
import xposed_service  # noqa: E402

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Dark Web Leak Monitoring API")

# Next.js frontend'in (localhost:3000) API'ye erişebilmesi için.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/v1/leaks")
def get_leaks(db: Session = Depends(get_db)):
    """Veritabanındaki tüm sızıntı kayıtlarını döner."""
    return db.query(BreachLog).order_by(BreachLog.id.desc()).all()


@app.get("/api/v1/scan")
async def scan(email: str, db: Session = Depends(get_db)):
    """
    Verilen e-posta için XposedOrNot, LeakIX ve AlienVault OTX servislerini
    PARALEL sorgular, sonuçları normalize edip veritabanına kaydeder ve
    bu taramada bulunan (yeni eklenen) kayıtları döner.
    """
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="Geçerli bir e-posta adresi girin.")

    domain = email.split("@")[-1]

    # --- 1. Üç servisi paralel çağır ---
    # return_exceptions=True: bir servis çökerse diğerlerini etkilemesin.
    xposed_raw, leakix_results, otx_results = await asyncio.gather(
        _safe_xposed_check(email),
        leakix_service.search_leakix(domain),
        otx_service.search_otx(domain),
        return_exceptions=True,
    )

    all_results: List[NormalizedLeak] = []

    if isinstance(xposed_raw, Exception):
        logger.error("XposedOrNot sorgusu hata verdi: %s", xposed_raw)
    else:
        all_results.extend(normalize_xposed_results(xposed_raw, email))

    if isinstance(leakix_results, Exception):
        logger.error("LeakIX sorgusu hata verdi: %s", leakix_results)
    else:
        all_results.extend(leakix_results)

    if isinstance(otx_results, Exception):
        logger.error("OTX sorgusu hata verdi: %s", otx_results)
    else:
        all_results.extend(otx_results)

    # --- 2. Tek seferde veritabanına yaz ---
    db_objects = [
        BreachLog(
            asset=item.asset,
            email_leak=item.email_leak,
            leaked_password=item.leaked_password,
            leak_type=item.leak_type,
            market=item.market,
            last_seen=item.last_seen,
            certainty=item.certainty,
            status=item.status,
            priority=item.priority,
            discovery_date=item.discovery_date,
        )
        for item in all_results
    ]

    if db_objects:
        db.add_all(db_objects)
        db.commit()
        for obj in db_objects:
            db.refresh(obj)

    return db_objects


async def _safe_xposed_check(email: str) -> list:
    """
    Mevcut xposed_service.py fonksiyonunuzu çağırır.
    Fonksiyon adı farklıysa burayı güncelleyin (örn. xposed_service.scan_email).
    """
    return await xposed_service.check_email(email)
